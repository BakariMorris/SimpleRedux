import React from 'react';



export const MobileCategory = (props) =>
    <div className='product-category-m'>
        <h4 className='product-category-m__text'>{props.category}</h4>
    </div>
